/* Cấu hình ánh xạ input -> output.
 * Mọi quy tắc nghiệp vụ nằm ở đây; sửa file này (hoặc màn hình Cấu hình trong tool)
 * là đủ khi web nguồn đổi tên cột / thêm luật lọc, không cần sửa code xử lý.
 *
 * Số dòng/cột trong file này đếm từ 1 giống Excel (headerRow: 10 = dòng 10).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AppConfig = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var DEFAULT_CONFIG = {
    /* "auto" = suy ra từ ngày xuất hiện nhiều nhất ở cột First response time
       của Session Report. Hoặc đặt cứng "2026-09-13". */
    reportDate: 'auto',

    /* --- Nguồn 1: Session Report (chat bot, tải từ FPT.AI Live Support) --- */
    session: {
      sheet: 0,
      headerRow: 1,
      dateColumn: 'First response time',
      /* Dòng khớp BẤT KỲ luật nào dưới đây sẽ bị loại.
         op: equalsIgnoreCase | equals | contains | isEmpty | regex */
      /* Bắt cả "lỗi bot" lẫn "lỗi" — file tổng ngày 15 bỏ thêm 1 dòng ghi mỗi "lỗi".
         Kiểm chứng: ngày 13 -> 12 dòng, ngày 14 -> 3 dòng, ngày 15 -> 21 dòng,
         khớp đúng số dòng file tổng đã bỏ ở cả 3 ngày. */
      dropRules: [
        { column: 'Description', op: 'regex', value: '^\\s*lỗi\\s*(bot)?\\s*$' }
      ],
      /* Tên sheet staging = tên sheet gốc + hậu tố này */
      stagingSuffix: ' (2)',
      /* 10 cột của sheet staging. from: "const" -> dùng value; còn lại là tên cột nguồn. */
      stagingColumns: [
        { out: 'TYPE', from: 'const', value: 'CHAT BOT' },
        { out: 'Customer', from: 'Customer' },
        { out: 'Supporter', from: 'Supporter' },
        { out: 'First response time', from: 'First response time' },
        { out: 'End time', from: 'End time' },
        { out: 'Description', from: 'Description' },
        { out: 'Notes', from: 'Notes' },
        { out: 'Topic level 1', from: 'Topic level 1' },
        { out: 'Sender id', from: 'Sender id' },
        { out: 'Ma kh', from: 'Ma kh' }
      ]
    },

    /* --- Nguồn 2: Daily Report CCVN (export Salesforce) --- */
    ccvn: {
      sheet: 0,
      /* Dò dòng header bằng chuỗi này thay vì đặt cứng số dòng */
      headerMarker: 'Case Number',
      /* Xoá cột rỗng nằm trong vùng header (cột C trong mẫu) */
      dropEmptyColumns: true,
      /* Dòng tổng ở cuối: giữ trong file sạch, bỏ khi dựng khối dán */
      totalRowMarker: 'Total',
      /* Ánh xạ sang khối "2. SF Case info" */
      caseColumns: [
        { out: 'Case information/案件情報: Case Number/案件番号', from: 'Case Number' },
        { out: 'Customer information/顧客情報:取引先名', from: 'Customer information' },
        { out: 'Case Status/案件ステータス', from: 'Case Status' },
        /* Export Salesforce đổi định dạng giữa chừng (`10:09 14/09/2026` thay vì
           `2026/09/14 10:09`) — chuẩn hoá về dạng file tổng vẫn dùng. */
        { out: '案件作成日時', from: '案件作成日時', format: 'datetime' },
        { out: 'Requested By/案件登録者', from: 'Created By' }
      ],
      /* Cột dùng để tra email supporter */
      supporterNameColumn: 'Created By',
      /* Ký tự thừa ở cuối tên cần cắt trước khi tra email và trước khi ghi ra.
         Export có "Dinh Thi Kim Oanh." (dấu chấm cuối) trong khi `mail SF` ghi
         "DINH THI KIM OANH" — không cắt thì 35-50 case mỗi ngày không tra được email. */
      nameTrimPattern: '[.,;\\s]+$'
    },

    /* Tên tài khoản Salesforce -> tên OP thật.
     * Phát hiện khi đối chiếu file mẫu: 38/379 case có cột `Requested By` của
     * File báo cáo tổng khác cột `Created By` của export, và khác theo đúng 2 cặp
     * dưới đây, áp dụng cho 100% số dòng của hai tên đó (19 + 19).
     * Hai tên đích (anh.np@, nguyen.nt@) cũng chính là 2 supporter chỉ xuất hiện ở
     * File báo cáo tổng mà không có trong file OP mẫu — khớp với giả thiết hai bạn này
     * lập case bằng tài khoản SF khác. Xoá cặp ở đây nếu quy tắc không còn đúng. */
    requestedByAliases: {
      'VU NHU QUYNH': 'NGUYEN PHUONG ANH',
      'LUU NGOC QUANG': 'NGUYEN THAO NGUYEN'
    },

    /* --- Nguồn 3: file báo cáo ngày của nhân viên (SBI DAILY REPORT_MMYY) --- */
    op: {
      cskh: {
        sheet: '1. CSKH',
        headerRow: 10,
        dataStartRow: 12,
        dateColumn: 'Date/日付',
        /* Cột nguồn (0-based) đem sang khối 1, tương ứng cột C..N của đích */
        copyColumns: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
      },
      /* Nhận cả dòng bị đảo ngày/tháng (lỗi locale khi nhập liệu).
       * Bật/tắt bằng ô tích ở bước 2. Dù bật hay tắt, tool luôn báo số dòng dính lỗi. */
      acceptSwappedDates: false,
      other: {
        sheet: '3. Other Tasks & Working time',
        headerRow: 5,
        dataStartRow: 7,
        dateColumn: 'DATE',
        /* Mỗi supporter chiếm đúng 1 khối liên tiếp bấy nhiêu dòng */
        blockSize: 8,
        /* Cột nguồn (0-based) đem sang khối 3, tương ứng cột C..L của đích.
           Index 2 là DATE - sẽ được ghi đè bằng serial ngày báo cáo. */
        copyColumns: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
      }
    },

    /* --- Cột ngày trong sheet Summarize_team VietNam ---
     * Sheet này cộng dồn cả tháng, mỗi ngày một cột. Tool điền các chỉ tiêu tính
     * được từ "1. CSKH"; những dòng còn lại (tồn đọng Salesforce, Head Count)
     * phải nhập tay vì không suy ra được từ 3 nguồn đầu vào.
     * Đã đối chiếu với cột ngày 13/9 trong file mẫu: cả 8 giá trị đều khớp. */
    summary: {
      sheet: 'Summarize_team VietNam',
      dayHeaderRow: 4,
      /* Giá trị cột CHANNEL của "1. CSKH" gộp vào nhóm nào.
         So khớp không phân biệt hoa thường nên "(BO Team)" và "(BO team)" gộp chung. */
      channelGroups: {
        chatbot: ['CHAT BOT'],
        zalo: ['Zalo T', 'Zalo L'],
        viber: ['Viber T', 'Viber L'],
        line: ['Line T', 'Line L', 'Line'],
        tel: ['Tel/Hotline', 'Tel'],
        outbound: ['Outbound'],
        sfcase: ['Xử lý case (BO Team)']
      },
      /* Kênh có thật nhưng không có dòng tương ứng trong bảng tổng hợp —
         liệt kê ở đây để khỏi bị cảnh báo "kênh lạ" mỗi lần chạy. */
      ignoredChannels: ['Trả lời Comment', 'JP khác', 'Outbound Reply', 'Gọi Outbound'],
      /* Dòng nào lấy số nào. Dòng không có ở đây thì tool KHÔNG đụng tới. */
      cells: [
        { row: 11, from: 'customerFormula', label: '①CUSTOMER' },
        { row: 12, from: 'chatbot', label: '1. FACEBOOK (CHAT BOT)' },
        { row: 13, from: 'zalo', label: '2. ZALO' },
        { row: 14, from: 'viber', label: '3. VIBER' },
        { row: 15, from: 'line', label: '4. LINE' },
        { row: 16, from: 'tel', label: '5. Telephone' },
        { row: 18, from: 'outbound', label: '② OUTBOUND' },
        { row: 28, from: 'sfcase', label: '⑨CCVN Case check&process' }
      ],
      /* ①CUSTOMER = số sender_id DUY NHẤT của CHAT BOT, cộng các kênh dòng 13-16.
         Đúng như công thức có sẵn trong file: =1378+SUM(R13:R16) với 1378 là số
         sender_id duy nhất của ngày 13/9. */
      customerFormula: '{distinct}+SUM({col}13:{col}16)',
      /* Các dòng tool không điền được — hiện trong cảnh báo để nhập tay. */
      manualRows: {
        '6': 'Đăng ký mới — Tổng',
        '7': '① APP', '8': '② WEBFORM', '9': '③ Kênh khác (CCC)',
        '17': '②Unprocessed/未対応',
        '20': '①CCVN On-processed', '21': '②CCVN Processing request (BM)',
        '22': '③CCVN Processing request', '23': '④CCVN Processing request',
        '24': '⑤CCVN Processing request (Other)', '25': '⑥CCVN Unprocessed',
        '26': '⑦CCVN waiting-response', '27': '⑧CCVN Completed',
        '29': 'Order HC', '30': 'Actual HC'
      }
    },

    /* --- KPI: tự tính lại chuỗi Sheet5 -> Daily KPI Result -> 202609 KPI Result ---
     *
     * Cột "Hiệu suất công việc" (W) của Daily KPI Result là công thức, chỉ có giá trị
     * sau khi Excel tính lại — nên không copy sang sheet KPI tháng được. Tool tự dựng
     * lại cả chuỗi từ dữ liệu thô:
     *
     *   pivot1 (đếm CHANNEL theo email, từ "1. CSKH")
     *     HTKH = Grand Total - case - CMT - JP khác      (cột OB/DKM của pivot luôn rỗng)
     *   pivot2 (đếm case theo Supporter email, từ "2. SF Case info")
     *   pivot3 (tổng giờ theo email, từ "3. Other Tasks")
     *
     *   E=HTKH   F=số case   G=max(0,E-F)   H=F*1.5+G
     *   mỗi mảng: hiệu suất*giờ = count/rate khi giờ>0, ngược lại 0
     *   W = tổng(count/rate) / tổng(giờ)
     *
     * Đã đối chiếu ngày 13/9: khớp 32/32 người, mọi cột trung gian đúng. */
    kpi: {
      /* 5 mảng KPI: [nguồn số lượng, cột giờ trong khối 3, định mức/giờ] */
      tracks: [
        { key: 'cskh', count: 'H', hoursColumn: 4, rate: 15 },
        { key: 'outbound', count: 'OB', hoursColumn: 5, rate: 30 },
        { key: 'case', count: 'case', hoursColumn: 6, rate: 17 },
        { key: 'comment', count: 'CMT', hoursColumn: 7, rate: 20 },
        { key: 'dkm', count: 'DKM', hoursColumn: 8, rate: 20 }
      ],
      /* Giá trị CHANNEL bị trừ khỏi HTKH (đúng công thức =I-P-Q-R-S-T-U+V của Sheet5) */
      caseChannels: ['Xử lý case (BO Team)'],
      commentChannels: ['Trả lời Comment'],
      otherChannels: ['JP khác'],
      /* Sheet KPI ngày — chỉ đọc để lấy danh sách OP và cập nhật ô ngày */
      daily: {
        sheet: 'Daily KPI Result',
        dateCell: 'A2',
        emailColumn: 3,
        dataStartRow: 15,
        dataEndRow: 43,
        totalRow: 14
      },
      /* Sheet KPI tháng — tên đổi theo tháng (202609, 202610…) nên dò bằng mẫu */
      monthly: {
        sheetPattern: '^\\d{6} KPI Result$',
        dateCell: 'A2',
        dayHeaderRow: 5,
        emailColumn: 3,
        dataStartRow: 6,
        dataEndRow: 60,
        teamRow: 7
      }
    },

    /* Công thức giữ lại khi ghi thẳng vào File báo cáo tổng.
     * {row} = số dòng hiện tại, {rowEnd} = dòng cuối của khối supporter.
     * Lấy đúng công thức đang có sẵn trong file tổng; sửa ở đây nếu file đổi. */
    masterFormulas: {
      sfcaseEmail: "VLOOKUP($F{row},'mail SF'!$C$3:$D$69,2,0)",
      otherTotal: 'SUM(G{row}:M{rowEnd})'
    },

    /* --- Ô neo khi dán vào File báo cáo tổng --- */
    targets: {
      cskh: { sheet: '1. CSKH', anchor: 'A11' },
      sfcase: { sheet: '2. SF Case info', anchor: 'B7' },
      other: { sheet: '3. Other Tasks & Working time', anchor: 'C6' }
    },

    /* Cột buộc ghi kiểu text. ID 16-17 chữ số ghi kiểu số sẽ mất chính xác
       (26793145563657353 > 2^53); timestamp ghi kiểu số sẽ bị Excel đổi định dạng. */
    textColumns: [
      'Sender id', 'Ma kh', 'Case Number', 'Conversation id',
      'First response time', 'End time', 'Requested time', 'Assign time',
      '案件作成日時'
    ],

    /* Vị trí bảng tra tên -> email trong File báo cáo tổng. Tool đọc bảng này mỗi
       lần chạy để soát tên trùng — tên trùng làm VLOOKUP gán case sai người. */
    mailSf: { sheet: 'mail SF', startRow: 3, nameColumn: 2, emailColumn: 3 },

    /* Bảng tra tên -> email, lấy từ sheet ẩn `mail SF` của File báo cáo tổng.
       Tra không phân biệt hoa thường và gộp khoảng trắng, giống VLOOKUP của Excel. */
    supporterEmails: {
      'DINH THI KIM OANH': 'oanh.dtk@altius-link.vn',
      'NGUYEN THI THUY TIEN': 'tien.ntt@altius-link.com.vn',
      'HOANG THE PHONG': 'phong.ht@altius-link.com.vn',
      'NGUYEN THUY TRANG': 'trang.nt@altius-link.com.vn',
      'DANG THI BICH': 'bich.dt@altius-link.com.vn',
      'NGUYEN THI NGOC THU': 'thu.ntn@altius-link.com.vn',
      'NGUYEN THI THANH THUY': 'thuy.ntt1@altius-link.com.vn',
      'TRAN TRUNG DUC': 'duc.tt@altius-link.com.vn',
      'NGUYEN TIEN THANG': 'thang.nt@altius-link.com.vn',
      'PHAM THI THU HOAI': 'hoai.ptt@altius-link.vn',
      'PHUNG LAN HUONG': 'huong.pl@altius-link.com.vn',
      'LE NGOC THUY': 'thuy.ln@altius-link.com.vn',
      'NGUYEN QUANG HUY': 'huy.nq1@altius-link.vn',
      'VU THI HONG VAN': 'van.vth1@altius-link.com.vn',
      'DANG NHAT MINH': 'minh.dn@altius-link.com.vn',
      'NGO QUANG THAI': 'thai.nq@altius-link.com.vn',
      'DINH THU THUY': 'thuy.dt@altius-link.com.vn',
      'LE QUANG HUY': 'huy.lq2@altius-link.com.vn',
      'VU NHU QUYNH': 'quynh.vn@altius-link.com.vn',
      'DINH THI QUYNH NHU': 'quynh.dtn1@altius-link.com.vn',
      'TRAN PHUONG THAO': 'thao.tp@altius-link.com.vn',
      'BUI THI KIM LINH': 'linh.btk@altius-link.com.vn',
      'NGUYEN HOANG LONG': 'long.nh@altius-link.com.vn',
      'PHAN THI HONG THUY': 'thuy.nth@altius-link.com.vn',
      'TRAN HUYEN TRANG': 'trang.th@altius-link.com.vn',
      'NGO QUOC BAO': 'bao.nq@altius-link.com.vn',
      'LUU NGOC QUANG': 'quang.ln@altius-link.com.vn',
      'BUI NGOC ANH': 'anh.bn1@altius-link.com.vn',
      'HOANG THI CUC': 'cuc.ht@altius-link.com.vn',
      'TA THI TRANG': 'trang.tt1@altius-link.com.vn',
      'TRAN THUY DUONG': 'duong.tt@altius-link.com.vn',
      /* `mail SF` có tên này 2 lần (dòng 34 -> ly.ntk@, dòng 43 -> ly.ntk1@).
         VLOOKUP lấy dòng khớp ĐẦU TIÊN nên phải là ly.ntk@. Nên dọn trùng ở file nguồn. */
      'NGUYEN THI KHANH LY': 'ly.ntk@altius-link.com.vn',
      'DANG QUANG MINH': 'minh.dq@altius-link.com.vn',
      'TRAN HUU QUANG LONG': 'long.thq@altius-link.com.vn',
      'LE PHUONG LINH': 'linh.lp@altius-link.com.vn',
      'DO PHUONG LINH': 'linh.dp1@altius-link.com.vn',
      'DO TU UYEN': 'uyen.dt@altius-link.com.vn',
      'LE VAN LONG': 'long.lv@altius-link.com.vn',
      'NGHIEM THU TRANG': 'trang.nt4@altius-link.com.vn',
      'DUONG HUY': 'huy.d@altius-link.com.vn',
      'TRAN LAN HUONG': 'huong.tl@altius-link.com.vn',
      'NGUYEN THAO NGUYEN': 'nguyen.nt@altius-link.com.vn',
      'NGUYEN PHUONG ANH': 'anh.np@altius-link.com.vn'
    }
  };

  /* Vị trí sheet `mail SF` trong File báo cáo tổng, dùng cho nút "nạp lại bảng email" */
  var MAIL_SF = { sheet: 'mail SF', startRow: 3, nameColumn: 2, emailColumn: 3 };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  return {
    DEFAULT_CONFIG: DEFAULT_CONFIG,
    MAIL_SF: MAIL_SF,
    defaults: function () { return clone(DEFAULT_CONFIG); },
    clone: clone
  };
});
